﻿using Microsoft.AspNetCore.Mvc;

namespace Joao_Cardoso___CP___MVC_RM552078.Controllers
{
    public class LoginController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
